# Simple Contact Book in Python

def show_menu():
    print("\n--- Contact Book Menu ---")
    print("1. Add Contact")
    print("2. View Contacts")
    print("3. Search Contact")
    print("4. Exit")

def add_contact():
    name = input("Enter name: ")
    phone = input("Enter phone number: ")
    email = input("Enter email: ")

    with open("contacts.txt", "a") as file:
        file.write(f"{name},{phone},{email}\n")
    print(f"✅ Contact '{name}' added successfully!")

def view_contacts():
    try:
        with open("contacts.txt", "r") as file:
            contacts = file.readlines()
            if not contacts:
                print("📭 No contacts found.")
            else:
                print("\n--- Contact List ---")
                for line in contacts:
                    name, phone, email = line.strip().split(",")
                    print(f"👤 {name} | 📞 {phone} | ✉️ {email}")
    except FileNotFoundError:
        print("📭 No contacts found.")

def search_contact():
    search = input("Enter name to search: ").lower()
    found = False
    try:
        with open("contacts.txt", "r") as file:
            for line in file:
                name, phone, email = line.strip().split(",")
                if search in name.lower():
                    print(f"✅ Found: 👤 {name} | 📞 {phone} | ✉️ {email}")
                    found = True
        if not found:
            print("❌ Contact not found.")
    except FileNotFoundError:
        print("📭 No contacts found.")

while True:
    show_menu()
    choice = input("Enter choice: ")

    if choice == "1":
        add_contact()
    elif choice == "2":
        view_contacts()
    elif choice == "3":
        search_contact()
    elif choice == "4":
        print("👋 Exiting Contact Book. Bye!")
        break
    else:
        print("❌ Invalid choice, try again.")
